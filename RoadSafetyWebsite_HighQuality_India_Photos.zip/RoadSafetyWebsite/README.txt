ROAD SAFETY AWARENESS WEBSITE

1. Extract this folder.
2. Open the folder in Visual Studio Code or another editor.
3. Open index.html in Chrome or Edge.
4. Use the navigation bar to switch pages.
5. Test the JavaScript buttons, road-sign dropdown and pledge form.

The five HTML pages use internal CSS and basic JavaScript. Photos are high-resolution Wikimedia Commons images and require an internet connection. See PHOTO_CREDITS.txt for authors and licences. The form is a front-end demonstration and does not save responses to a database.
